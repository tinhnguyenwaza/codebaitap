package BàiTapASM3;

public interface Salary {
	double Salary();
	
}
